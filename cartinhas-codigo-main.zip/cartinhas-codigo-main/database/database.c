#include "database.h"

int kidsLen = 0;
int godfathersLen = 0;
DATABASET database;
