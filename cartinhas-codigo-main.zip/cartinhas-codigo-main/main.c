#include "pages/pageRenderer.h"
#include "pages/homePage.h"

int main()
{
    renderPage(homePage);

    return 0;
}