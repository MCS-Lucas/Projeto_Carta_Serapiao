#ifndef HOMEPAGE_H
#define HOMEPAGE_H

void homePage();
#endif
