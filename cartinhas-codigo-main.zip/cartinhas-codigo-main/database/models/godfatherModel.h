#include "../../structs/godfather.h"

#ifndef GODFATHERMODEL_H
#define GODFATHERMODEL_H

void insertGodfather(GODFATHER godfather);
int godfatherExists(char *cpf);

#endif