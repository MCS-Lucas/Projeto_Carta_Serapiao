#ifndef LOGINKIDPAGE_H
#define LOGINKIDPAGE_H

void loginKidPage();
#endif
