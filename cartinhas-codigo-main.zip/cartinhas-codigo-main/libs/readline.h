#ifndef READLINE_H
#define READLINE_H

signed int keyInSelect(char **options, char *question);

#endif