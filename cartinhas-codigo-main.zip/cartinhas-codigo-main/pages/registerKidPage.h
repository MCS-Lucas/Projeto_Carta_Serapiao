#ifndef REGISTERKIDPAGE_H
#define REGISTERKIDPAGE_H

void registerKidPage();

#endif
