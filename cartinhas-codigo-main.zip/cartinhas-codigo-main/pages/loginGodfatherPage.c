#include "loginGodfatherPage.h"
#include <stdio.h>

void loginGodfatherPage()
{
    printf("Login godfather");
}