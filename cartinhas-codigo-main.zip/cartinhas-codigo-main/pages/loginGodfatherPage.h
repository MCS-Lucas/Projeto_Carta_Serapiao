#ifndef LOGINGODFATEHRPAGE_H
#define LOGINGODFATEHRPAGE_H

void loginGodfatherPage();
#endif