#ifndef PAGERENDERER_H
#define PAGERENDERER_H

void renderPage(void (*page)());

void goToPage(void (*page)());

#endif