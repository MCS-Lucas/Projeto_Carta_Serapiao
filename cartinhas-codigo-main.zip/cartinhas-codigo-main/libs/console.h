#ifndef CONSOLE_H
#define CONSOLE_H

void clrscr();

void input(char *msg, void *output, char *format);

#endif