#ifndef IDGENERATOR_H
#define IDGENERATOR_H

char *generateID();

#endif