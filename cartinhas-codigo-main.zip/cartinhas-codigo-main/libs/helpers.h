
#ifndef HELPERS_H
#define HELPERS_H

void printBeautifulMsg(char *);

#endif