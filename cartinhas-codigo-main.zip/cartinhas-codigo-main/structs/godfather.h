#ifndef GODFATHERSTRUCT_H
#define GODFATHERSTRUCT_H

struct godfather
{
    char cpf[255];
    char name[255];
    char phone[255];
    char email[255];
    char password[255];
};

typedef struct godfather GODFATHER;

#endif