#ifndef REGISTERGODFATHER_H
#define REGISTERGODFATHER_H

void registerGodfather();
#endif
